from __future__ import annotations

import argparse
import json
import sys

from .logs import inspect


def main() -> int:
    parser = argparse.ArgumentParser(description="Inspect a recording for a session metrics build")
    parser.add_argument("command", choices=["inspect"])
    parser.add_argument("source")
    parser.add_argument("--timestamp-field", default="timestamp_ns")
    parser.add_argument("--timestamp-unit", choices=["ns", "us", "ms", "s"], default="ns")
    parser.add_argument("--hdf5-group", default="/")
    args = parser.parse_args()
    try:
        result = inspect(
            args.source,
            timestamp_field=args.timestamp_field,
            timestamp_unit=args.timestamp_unit,
            hdf5_group=args.hdf5_group,
        )
    except Exception as error:
        print(json.dumps({"complete": False, "error": str(error)}), file=sys.stderr)
        return 1
    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
