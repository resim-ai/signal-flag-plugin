from __future__ import annotations

import builtins
import json
from collections import Counter
from collections.abc import Callable, Iterator
from dataclasses import dataclass, is_dataclass
from dataclasses import fields as dataclass_fields
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

from .reader import UNDECODABLE, LogError, LogReader
from .remote import open_source

FORMATS = {
    ".mcap": "mcap",
    ".log": "text",
    ".txt": "text",
    ".jsonl": "text",
    ".parquet": "parquet",
    ".h5": "hdf5",
    ".hdf5": "hdf5",
    ".bag": "ros1bag",
}
UNITS = {"ns": 1, "us": 1000, "ms": 1_000_000, "s": 1_000_000_000}


@dataclass(frozen=True)
class Record:
    topic: str
    timestamp_ns: int | None
    data: Any
    recording_key: str


def relative_key(key: str) -> str:
    if not isinstance(key, str) or not key or key.startswith("/") or "\\" in key:
        raise ValueError("recording key must be relative to the session folder")
    if any(part in {"", ".", ".."} for part in key.split("/")) or any(ord(c) < 32 for c in key):
        raise ValueError("recording key contains an unsafe path component")
    return key


def epoch_ns(value: Any, unit: str = "ns") -> int | None:
    if unit not in UNITS:
        raise ValueError(f"unsupported timestamp unit: {unit}")
    if value is None:
        return None
    if isinstance(value, bool) or isinstance(value, float):
        raise ValueError("timestamps must be integers or decimal strings, not floats")
    try:
        number = Decimal(str(value)) * UNITS[unit]
        if not number.is_finite() or number < 0 or number != number.to_integral_value():
            raise ValueError("timestamp must resolve to nonnegative integral nanoseconds")
        return int(number)
    except InvalidOperation as error:
        raise ValueError("invalid timestamp") from error


class Recording:
    def __init__(
        self,
        source: str | Path,
        *,
        recording_key: str | None = None,
        timestamp_field: str = "timestamp_ns",
        timestamp_unit: str = "ns",
        text_parser: Callable[[str], dict[str, Any]] | None = None,
        hdf5_group: str = "/",
        s3_client=None,
    ):
        self.source = str(source)
        self.key = relative_key(recording_key or Path(urlsplit(self.source).path).name)
        self.format = FORMATS.get(Path(urlsplit(self.source).path).suffix.lower())
        if self.format is None:
            raise ValueError(f"unsupported recording format: {self.key}")
        if timestamp_unit not in UNITS:
            raise ValueError(f"unsupported timestamp unit: {timestamp_unit}")
        self.timestamp_field = timestamp_field
        self.timestamp_unit = timestamp_unit
        self.text_parser = text_parser
        self.hdf5_group = hdf5_group
        self.s3_client = s3_client

    def iter_messages(self, topics: set[str] | None = None) -> Iterator[Record]:
        if self.format == "mcap":
            with open_source(self.source, s3_client=self.s3_client) as stream:
                reader = LogReader(stream).open()
                for channel, message in reader.iter_messages(topics):
                    data = reader.decode(channel, message)
                    if data is UNDECODABLE:
                        raise LogError(f"cannot decode {self.key}:{channel.topic}")
                    yield Record(channel.topic, message.log_time, data, self.key)
                if reader.decode_failures:
                    raise LogError(f"incomplete recording {self.key}: {reader.decode_failures}")
            return
        if urlsplit(self.source).scheme:
            raise ValueError("non-MCAP readers require a local copied recording")
        if self.format == "ros1bag":
            from rosbags.highlevel import AnyReader

            with AnyReader([Path(self.source)]) as reader:
                connections = [c for c in reader.connections if topics is None or c.topic in topics]
                if not connections:
                    return
                for connection, timestamp, raw in reader.messages(connections=connections):
                    yield Record(
                        connection.topic, timestamp, reader.deserialize(raw, connection.msgtype), self.key
                    )
            return
        for topic, row in self._rows():
            if topics is None or topic in topics:
                yield Record(
                    topic, epoch_ns(row.get(self.timestamp_field), self.timestamp_unit), row, self.key
                )

    def _rows(self) -> Iterator[tuple[str, dict[str, Any]]]:
        if self.format == "text":
            with builtins.open(self.source, encoding="utf-8") as source:
                for line in source:
                    if not line.strip():
                        continue
                    if self.text_parser:
                        row = self.text_parser(line.rstrip("\r\n"))
                    elif line.lstrip().startswith("{"):
                        row = json.loads(line)
                    else:
                        row = {"message": line.rstrip("\r\n")}
                    if not isinstance(row, dict):
                        raise ValueError("text parser must return an object")
                    yield self.key, row
        elif self.format == "parquet":
            import pyarrow.parquet as parquet

            with parquet.ParquetFile(self.source) as source:
                for batch in source.iter_batches(batch_size=4096):
                    for row in batch.to_pylist():
                        yield self.key, row
        elif self.format == "hdf5":
            import h5py

            with h5py.File(self.source, "r") as source:
                group = source[self.hdf5_group]
                if not isinstance(group, h5py.Group):
                    raise ValueError("hdf5_group must identify a group of aligned column datasets")
                columns = dict(group.items())
                if not columns or any(
                    not isinstance(c, h5py.Dataset) or c.ndim != 1 for c in columns.values()
                ):
                    raise ValueError("HDF5 group must contain one-dimensional column datasets")
                if len({len(c) for c in columns.values()}) != 1:
                    raise ValueError("HDF5 columns have different lengths")
                for index in range(len(next(iter(columns.values())))):
                    row = {name: _scalar(column[index]) for name, column in columns.items()}
                    yield self.hdf5_group, row

    def inspect(self) -> dict[str, Any]:
        counts: Counter[str] = Counter()
        missing = 0
        start = end = None
        fields: dict[str, set[str]] = {}
        for record in self.iter_messages():
            counts[record.topic] += 1
            fields.setdefault(record.topic, set()).update(_field_paths(record.data))
            if record.timestamp_ns is None:
                missing += 1
            else:
                start = record.timestamp_ns if start is None else min(start, record.timestamp_ns)
                end = record.timestamp_ns if end is None else max(end, record.timestamp_ns)
        return {
            "recording_key": self.key,
            "format": self.format,
            "message_count": sum(counts.values()),
            "topics": dict(counts),
            "fields": {k: sorted(v) for k, v in fields.items()},
            "start_ns": start,
            "end_ns": end,
            "unclocked_messages": missing,
            "complete": True,
        }


def _scalar(value: Any) -> Any:
    if isinstance(value, bytes):
        return value.decode("utf-8")
    return value.item() if hasattr(value, "item") else value


def _field_paths(value: Any, prefix: str = "", depth: int = 0) -> Iterator[str]:
    if depth >= 8:
        return
    if isinstance(value, dict):
        items = value.items()
    elif is_dataclass(value) and not isinstance(value, type):
        items = (
            (field.name, getattr(value, field.name))
            for field in dataclass_fields(value)
            if not field.name.startswith("__")
        )
    else:
        return
    for name, child in items:
        path = f"{prefix}.{name}" if prefix else str(name)
        yield path
        yield from _field_paths(child, path, depth + 1)


def open(source: str | Path, **options) -> Recording:
    return Recording(source, **options)


def iter_messages(source: str | Path, **options) -> Iterator[Record]:
    return open(source, **options).iter_messages()


def inspect(source: str | Path, **options) -> dict[str, Any]:
    return open(source, **options).inspect()
